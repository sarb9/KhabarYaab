import React, { Component } from "react";
import "./styles/About.css";
export class About extends Component {
  render() {
    return (
      <div className="About">
        <h1>Authors </h1>
        <br />
        <br />
        <p>Alireza Arad Milad</p>
      </div>
    );
  }
}

export default About;
